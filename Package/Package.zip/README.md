# CurbYourDeath
Soundmod that plays frolic from curb your enthusiasm when you lose the run.

## Changelog

### 1.1.0
- No longer plays sound on victory or obliteration

### 1.0.1
- Remove leftover debugging code

### 1.0.0
- Release